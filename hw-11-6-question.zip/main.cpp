#include <iostream>
using namespace std;

int main()
{
    int index;
    float prem, rate, new_prem;
    cout << "Enter current premium $";
    cin >> prem;
    index = prem/400;
    switch (index)
        {
            case 5: rate = prem*0.2;
                    break;
            case 4: rate = prem*0.15;
                    break;
            case 3: rate = prem*0.12;
                    break;
            case 2: rate = prem*0.1;
                    break;
            case 1: rate = prem*0.05;
                    break;
            case 0: rate = prem*0.05;
                    break;
            default: rate = 500;
        }
    new_prem = prem - rate;
    cout << "The new premium is= $" << new_prem << endl;
}


