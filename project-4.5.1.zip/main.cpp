#include <iostream>
#include <math.h>
using namespace std;
//Chrisin Jacob
/*The following program analyzes the stock of Witter Investment Co. and decided whether to buy the stock or not*/

int main()
{
    float price, minval = 1000, maxval = 0, avg, sum1 = 0, cnt = 0;
    float fluc_width, fluc_mean, price_change, prev_price, sum2 = 0;
    cout << "Enter the price ";
    cin >> price;
    prev_price = price;
    while (price != -1) //The loop will continue till the user enters -1
        {
            cnt++;
            sum1 += price;
            avg = sum1/cnt; // This calculates the average
            if (price < minval)
                minval = price;
            if (price > maxval)
                maxval = price;
            price_change = price - prev_price; 
            sum2 += (price_change*price_change);
            prev_price = price;
            cout << "Enter the price (enter -1 to terminate) ";
            cin >> price;
        }
    fluc_width = maxval - minval; //This calculates the fluctuation width
    fluc_mean = sqrt (sum2/(cnt - 1)); //This calculates the fluctuation mean
    cout << "Average price = " << avg << endl;
    cout << "Fluctuation width = " << fluc_width << endl;
    cout << "Fluctuation mean = " << fluc_mean << endl;
    if (price < avg && (fluc_width < (avg/3) || fluc_mean < (avg/3))) //This decides whether the user needs to buy the stock or not
        cout << "Conclusion: Buy this stock" << endl;
    else 
        cout << "Conclusion: Do not buy this stock" << endl;
}
