#include <iostream>
using namespace std;

void title();
int prime (int);
int main()
{
    int a = 2, m;
    title();
    while (a < 20)
        {
            if (prime(a) == 1)
                cout << a << " , ";
            a++;
        }
}
int prime (int x)
{
    int test = 2;
    while (test < x)
        {
            if (x % test == 0)
                return 0;
            test++;
        }
    return 1;
}
void title()
{
    cout << "Prime Numebers" << endl;
    cout << "**************" << endl;
}

