#include <iostream>
using namespace std;
//Chrisin Jacob
/*The following program computes the system to calculate and prepare a report for 
David Klein's and the Office of Parking Services' daily shares of earned income*/
int main()
{
    float penny, nickel, dime, quarter, total_dollar_value, david_amount, office_amount, david_rounded_amount, office_rounded_amount;
    cout << "Enter the number of pennies collected = ";
    cin >> penny;
    cout << "Enter the number of nickels collected = ";
    cin >> nickel;
    cout << "Enter the number of dimes collected = ";
    cin >> dime;
    cout << "Enter the number of quarters collected = ";
    cin >> quarter;
    total_dollar_value = (penny/100) + (nickel/20) + (dime/10) + (quarter/4);
    cout << "The total amount of money collected today (in dollars) = $" << total_dollar_value << endl;
    david_amount = (((0.24 * total_dollar_value)*100) + 0.5);
    david_rounded_amount = (int)david_amount / 100.0;  
    cout << "The total amount of money David earned today = $" << david_rounded_amount << endl;
    office_amount = (((0.76 * total_dollar_value)*100) + 0.5);
    office_rounded_amount = (int)office_amount / 100.0;
    cout << "The total amount of money the Office earned today = $" << office_rounded_amount << endl;
}

