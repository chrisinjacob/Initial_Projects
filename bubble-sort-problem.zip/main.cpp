#include <iostream>
using namespace std;

void bubble_sort (float[], int);
int main()
{
    float num[15] = {4.3, 5.2, 8.9, 1.3, 6.7, 9.3, 8.9, 12.4, 3.7, 15.3, 23.4, 3.7, 5.6, 8.5, 4.7};
    bubble_sort (num, 15);
    int i = 0;
    while (i < 15)
        {
            cout << num[i] << endl;
            i++;
        }
}
void bubble_sort (float n[], int size)
{
    int i = 0, j = 1;
    float a;
    while (j < size)
        {
            i = 0;
            while (i < size - j)
                {
                    if (n[i] > n[i + 1])
                        {
                            a = n[i];
                            n[i] = n[i + 1];
                            n[i + 1] = a;
                        }
                    i++;
                }
          j++;
        }
}
