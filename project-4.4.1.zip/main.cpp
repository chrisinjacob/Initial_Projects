#include <iostream>
using namespace std;
//Chrisin Jacob - Section 4.4
/*The following program obtains an n integer from the user and finds and prints the nth Fibonacci number*/

int main()
{
    int n, n1 = 1, n2 = 1, cnt = 2, nxtterm;
    cout << "Enter an integer greater than 2 = ";
    cin >> n;
    /*The program will show invalid, if the entered integer is less than or equal to 2*/
    if (n <= 2)
        cout << "Invalid - Enter an integer greater than 2" << endl ;
    /*The while condition is true when the count is less than the number entered by the user*/
    else 
        {
            while (cnt < n)
                {
                    /*n1 & n2 gets added (loop continues) till the while condition becomes false*/
                    nxtterm = n1 + n2;
                    n1 = n2;
                    n2 = nxtterm;
                    cnt++;
                }
                    /*The below cout will display the last value stored by nxtterm, ie: before the condition becomes false*/
                    cout << "The Fibonacci number is = " << nxtterm << endl;
        }
}


