#include <iostream>
using namespace std;

//Chrisin Jacob
/*The following program computes the monthly bill of Pringle Water Co.'s customers*/

int main()
{
    int id_num, ans;
    float a, b, units, rate, total_bill, tax, final_bill;
    cout <<"Enter customer identification number ";
    cin >> id_num;
    cout << "Enter last reading of the water meter ";
    cin >> a;
    cout << "Enter new reading of the water meter ";
    cin >> b;
    cout << "Are you in the Super Savings Plan? (Enter 1 for Yes and 0 for No) ";
    cin >> ans;
    units = b - a;
    /*The below calculates the charge rate */
    if (units < 200)
        rate = (8*units)/100.;
    else if (units < 800)
        rate = (7*units)/100.;
    else
        rate = (5*units)/100.;
    /*The below bill is the total bill for those in the super savings plan*/
    total_bill = 8 + rate + 6;
    if (ans == 1)
        /*Those in the super savings plan and whose total bill is greater than $35 will get a discount */
        if (total_bill > 35)
                total_bill = total_bill - total_bill*0.2;
        else 
                total_bill = total_bill;
    /*The below is the total bill for those not in the super savings plan*/
    else 
        total_bill = total_bill - 6;
    tax = total_bill*0.06;
    final_bill = (int)(((total_bill + tax)*100) + 0.5) / 100.;
    cout << "Customer ID: " << id_num << endl;
    if (ans == 1)
        cout << "\tSuper Saver?" << "\t\t\t:" << "Yes" << endl;
    else
        cout << "\tSuper Saver?" << "\t\t\t:" << "No" << endl;
    cout << "\tPrevious reading" << "\t\t:" << a << endl 
    << "\tNew reading" << "\t\t\t:" << b << endl 
    << "\tNumber of units of water used   :" << units << endl 
    << "\tCharges" << "\t\t\t\t:$" << total_bill << endl 
    << "\tTax" << "\t\t\t\t:$" << tax << endl
    << "\tAmount due" << "\t\t\t:$" << final_bill << endl;
}



