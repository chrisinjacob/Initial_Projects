#include <iostream>
using namespace std;
#include <stdlib.h>

int main()
{
    int bet = 1, win, face, cnt = 1;
    while (bet <= 5)
        {
            win = 0;
            while (cnt <= 100)
                {
                    face = rand() % 6 + 1;
                    win -= bet;
                    if (face < bet)
                        win += 5;
                    cnt++;
                }
            cout << bet << " " << win << endl;
            bet++;
        }
}

