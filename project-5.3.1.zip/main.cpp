#include <iostream>
#include <stdlib.h>
using namespace std;
//Chrisin Jacob
/*The following program determines the wins of a player after playing the game 500 times*/

int p (int);
int main()
{
    int x, face1, face2, sum1 = 0, i = 1, cnt = 0;
    while (i <= 500)
        {
            face1 = rand() % 6 + 1;
            face2 = rand() % 6 + 1;
            sum1 = face1 + face2;
            if (p(sum1) == 1)
                cnt++;
            i++;
        }
    cout << "The player has won "  << cnt << " times";
}
int p(int sum2)
{
    int testnum = 2;
    while (testnum <= sum2/2.)
        {
            if (sum2 % testnum == 0)
                return 0;
            testnum++;
        }
    return 1;
}
