#include <iostream>
using namespace std;
//Chrisin Jacob
/*The following program computes the best fitting straight line and finds the resistances at the required temperatures*/

int main()
{
    float temp[15], resist[15], t = 10, r, sumtemp = 0, sumresist = 0, sum1 = 0, sum2 = 0; 
    float avg_temp, avg_resist, m, b;
    int i = 0;
    //First the user enters the temperature and resistance
    cout << "Enter the temperature ";
    cin >> temp[i];
    cout << "Enter the resistance ";
    cin >> resist[i];
    while (temp[i] != -1 && i < 15) //The loop will continue till -1 is entered by the user
        {
            //The following will calculate the sums needed for the average of temperatures and resistance
            sumtemp += temp[i];
            sumresist += resist[i];
            //The following will calculate the sums to find the value of m and b
            sum1 += temp[i]*resist[i];
            sum2 += temp[i]*temp[i];
            i++;
            //The user has to enter the temperature and resistance till -1 is entered
            cout << "Enter the temperature (enter -1 to terminate) ";
            cin >> temp[i];
            cout << "Enter the resistance ";
            cin >> resist[i];
        }
    //The following will terminate the program if more than 15 pairs of data is entered
    if (i == 15)
        {
            cout << "Data entered exceeds the given amount. Only 15 pairs of data is allowed" << endl;
            return 0;
        }
    //The following will calculate the average of temperature and resistance
    avg_temp = sumtemp/i;
    avg_resist = sumresist/i;
    //The following will calculate the values of m and b
    m = (sum1 - sumtemp*avg_resist) / (sum2 - sumtemp*avg_temp);
    b = avg_resist - m*avg_temp;
    cout << "Temperature" << "\t" << "Resistance" << endl;
    while (t >= -5) //The loop will continue till -5
        {
            //The following calculates and prints the resistances at the required temeperatures
            r = m*t + b;
            cout << t << "\t\t" << r << endl;
            t--;
        }
}




