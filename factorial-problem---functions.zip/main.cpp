#include <iostream>
using namespace std;

int fact (int x)
{
    int prod = 1, m = 2;
    while (m <= x)
        {
            prod *= m;
            m++;
        }
    return prod;
}
int main()
{

}
