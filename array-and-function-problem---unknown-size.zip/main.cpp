#include <iostream>
using namespace std;

float big (float[], int);
int main()
{
    float num[100];
    int i = 0;
    cout << "Enter grade, in number formats";
    cin >> num[i];
    while (num[i] != -1 && i < 100)
        {
            i++;
            cout << "Enter grade (enter -1 to terminate) ";
            cin >> num[i];
        }
    if (i == 100)
        {
            cout << "Too many data";
            return 0;
        }
    cout << big (num, i);
}
float big (float val[], int size)
{
    int j = 1, max = val[0];
    while (j <= size - 1)
        {
            if (val[j] > max)
                max = val[j];
            j++;
        }
    return max;
}


