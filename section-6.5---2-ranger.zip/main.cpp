#include <iostream>
using namespace std;

float ranger (float[], int);
int main()
{
    float num[3];
    int i = 0;
    while (i < 3)
        {
            cout << "Enter grade";
            cin >> num[i];
            i++;
        }
    cout << ranger (num, 3);
}
float ranger (float val[], int size)
{
    int j = 1;
    float range, max = val[0], min = val[0];
    while (j <= size - 1)
        {
            if (val[j] > max)
                max = val[j];
            if (val[j] < min)
                min = val[j];
            j++;
        }
    range = max - min;
    return range;
}