#include <iostream>
using namespace std;

int isPrime (int x)
{
    int test = 2;
    while (test < x)
        {
            if (x % test == 0)
                return 0;
            test++;
        }
    return 1;
}
int main()
{
    int a, m;
    cout << "Enter ";
    cin >> a;
    m = isPrime (a);
    if (m == 1)
        cout << "Prime";
    else 
     cout << "Not prime";
}

