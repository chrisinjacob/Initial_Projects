#include <iostream>
using namespace std;

int search (char[], int, char);
int main()
{
    char alpha[26], a;
    int i = 0;
    while (i < 26)
        {
            alpha[i] = 'a' + i;
            i++;
        }
    cout << "Enter a character";
    cin >> a;
    if (search (alpha, 26, a) != -1)
        cout << search (alpha, 26, a);
    else 
        cout <<"Not in the data";
}
int search (char val[], int size, char x)
{
    int j = 0;
    while (j < size)
        {
            if (val[j] == x)
                return j;
            j++;
        }
    return -1;
}

